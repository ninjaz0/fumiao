// plugins/gpu/src/index.ts
import {
  ProviderError
} from "fumiao:packages/plugin-sdk/src/index.js";
var videoQualities = [480, 768];
var videoSeconds = [5, 10, 15];
var gpu = {
  manifest: {
    id: "gpu",
    version: "1.0.0",
    contractVersion: 1,
    label: "GPU \u5DE5\u4F5C\u8282\u70B9",
    mode: "pull",
    configSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    },
    models: [
      {
        id: "MiniMax H3",
        label: "MiniMax H3",
        kind: "video",
        inputSchema: {
          type: "object",
          additionalProperties: false,
          "x-references": { types: ["image"], max: 4 },
          properties: {
            ratio: {
              type: "string",
              enum: ["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"],
              default: "16:9"
            },
            quality: { type: "integer", enum: videoQualities, default: 480 },
            seconds: { type: "integer", enum: videoSeconds, default: 5 },
            sampling_steps: {
              type: "integer",
              enum: [4, 16, 20, 32, 50],
              default: 20
            },
            seed: { type: "integer", minimum: 0, maximum: 9007199254740991 }
          }
        }
      },
      {
        id: "breeze-tts-2",
        label: "Breeze TTS 2",
        kind: "audio",
        inputSchema: {
          type: "object",
          additionalProperties: false,
          "x-references": { max: 0 },
          properties: {
            instruction: { type: "string", maxLength: 300 },
            seed: { type: "integer", minimum: 0, maximum: 4294967295 }
          }
        }
      }
    ]
  },
  async health() {
    return true;
  },
  async submit() {
    throw new ProviderError("\u7B49\u5F85 GPU \u8282\u70B9\u4E3B\u52A8\u9886\u53D6", "retryable");
  }
};

// plugins/gpu/src/timing.ts
import { createHash } from "node:crypto";

// plugins/gpu/src/reference-limits.ts
var referenceLimits = {
  min: 0,
  max: 12,
  counts: { image: 9, video: 3, audio: 3 },
  minSeconds: 2,
  maxSeconds: 15
};

// plugins/gpu/src/studio.ts
import {
  choices,
  displayRatios
} from "fumiao:packages/plugin-sdk/src/model-form.js";
var runtime = JSON.parse(
  '{\n  "MiniMax H3": {\n    "label": "MiniMax H3",\n    "slug": "minimax-h3",\n    "kind": "video",\n    "adapter": "h3",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 96,\n    "min_ram_gib": 128,\n    "disk_gib": 155,\n    "min_python": [\n      3,\n      12\n    ],\n    "manifest": "engine/assets/models.lock.json",\n    "cache_env": "H3_CACHE",\n    "cache_dir": "fumiao-h3",\n    "model_subdir": "models",\n    "persistence_priority": 0,\n    "precision": "bf16",\n    "workflow": "h3-v3-rocm-qkv-safe"\n  },\n  "breeze-tts-2": {\n    "label": "Breeze TTS 2",\n    "slug": "breeze-tts-2",\n    "kind": "audio",\n    "adapter": "breeze",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 12,\n    "min_ram_gib": 16,\n    "disk_gib": 20,\n    "min_python": [\n      3,\n      10\n    ],\n    "manifest": "breeze.lock.json",\n    "cache_env": "BREEZE_HOME",\n    "cache_dir": "fumiao-breeze",\n    "model_subdir": "checkpoint",\n    "persistence_priority": 10,\n    "precision": "bf16",\n    "workflow": "breeze-tts-2-eager-v1"\n  }\n}\n'
);
var gpuStudio = {
  ...gpu,
  modelForm(model) {
    const fields = model.inputSchema.properties;
    const video2 = model.kind === "video";
    const native2 = video2 && !!fields.h3;
    return {
      fields: video2 ? {
        ratio: choices(displayRatios, "16:9"),
        quality: fields.quality,
        seconds: fields.seconds,
        sampling_steps: fields.sampling_steps,
        seed: fields.seed
      } : { instruction: fields.instruction, seed: fields.seed },
      references: native2 ? referenceLimits : {
        min: 0,
        max: Number(
          model.inputSchema["x-references"].max
        )
      },
      ...native2 ? { referenceModes: ["reference", "frames"] } : {},
      ...video2 ? { fastSteps: 4 } : {},
      tiers: model.studio.prices.map(({ tier, match }) => ({
        tier,
        when: Object.fromEntries(
          Object.entries(match.properties ?? {}).map(([k, v]) => [
            k,
            [v.const]
          ])
        )
      }))
    };
  },
  manifest: {
    ...gpu.manifest,
    version: "1.1.0",
    models: gpu.manifest.models.map((model) => ({
      ...model,
      studio: {
        order: model.kind === "video" ? 0 : 4,
        priceOrder: model.kind === "video" ? 0 : 40,
        descriptor: { kind: model.kind, label: model.label },
        runtime: runtime[model.id],
        prices: model.kind === "video" ? videoQualities.flatMap(
          (quality) => videoSeconds.map((seconds) => ({
            tier: `${quality}|${seconds}`,
            label: `${quality}P \xB7 ${seconds}s`,
            amount: null,
            match: {
              type: "object",
              required: ["quality", "seconds"],
              properties: {
                quality: { const: quality },
                seconds: { const: seconds }
              }
            }
          }))
        ) : [
          {
            tier: "standard",
            label: "\u8BED\u97F3\u751F\u6210",
            amount: 1,
            match: { type: "object" }
          }
        ]
      }
    }))
  }
};

// plugins/gpu/src/timing.ts
var standard = "h3-v3-rocm-qkv-safe-standard20";
var oldFast = "h3-v5-rocm-qkv-safe-turbo4";
var fast = "h3-v6-native-inputs-turbo4";
var ratios = {
  "16:9": [864, 480, 1344, 768],
  "9:16": [480, 864, 768, 1344],
  "1:1": [480, 480, 768, 768],
  "4:3": [640, 480, 1024, 768],
  "3:4": [480, 640, 768, 1024],
  "21:9": [1120, 480, 1568, 672]
};
var sha = (s) => createHash("sha256").update(s).digest("hex");
function pythonString(value) {
  return value === true ? "True" : value === false ? "False" : value === null ? "None" : String(value);
}
function pythonFloat(value) {
  if (value !== 0 && Math.abs(value) < 1e-4)
    return value.toExponential().replace(/e([+-])(\d)$/, "e$10$2");
  return Number.isInteger(value) ? value.toFixed(1) : String(value);
}
function hardwareSignature(profile) {
  if (!String(profile.gpu_name || "").trim()) return "";
  const keys = [
    "backend",
    "gpu_name",
    "vram_gib",
    "used_gpus",
    "runtime",
    "driver",
    "torch_version",
    "precision",
    "attention",
    "memory_mode"
  ].sort();
  const encode = (s) => JSON.stringify(s).replace(
    /[\u007f-\uffff]/g,
    (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0")
  );
  return sha(
    "{" + keys.map(
      (k) => encode(k) + ": " + encode(
        (k === "vram_gib" && profile.vram_gib !== void 0 ? pythonFloat(profile.vram_gib) : pythonString(profile[k] ?? "")).trim().toLowerCase()
      )
    ).join(", ") + "}"
  ).slice(0, 32);
}
function preset(p, refs) {
  const meta = p.h3_inputs || {}, reference = Object.keys(meta).length ? meta.mode === "reference" && refs > 0 : refs > 1;
  return reference ? "ref2v-v01" : Number(p.quality ?? 480) === 768 ? "fl2v-768-v10" : "fl2v-low-v10";
}
function pipeline(p, refs) {
  const meta = p.h3_inputs || {};
  let mode;
  if (meta.mode === "frames")
    mode = meta.first_frame && meta.last_frame ? "fl2v" : meta.last_frame ? "l2v" : meta.first_frame ? "i2v" : "t2v";
  else if (meta.mode === "reference") {
    mode = refs ? "r2v" : "t2v";
    for (const kind of ["video", "audio"])
      if ((meta.files || []).some((f) => f.kind === kind))
        mode += "+" + kind;
  } else mode = p.video_mode || (refs > 1 ? "r2v" : refs ? "i2v" : "t2v");
  if ((p.sampling_steps ?? p.steps ?? 20) !== 4) return mode;
  const workflow = p.workflow || "", variant = workflow.startsWith("h3-turbo4-") ? workflow : ["", oldFast, fast].includes(workflow) ? "h3-turbo4-" + preset(p, refs) : "legacy-fast4:" + workflow;
  return mode + "|" + variant;
}
var gpuTiming = {
  ...gpuStudio,
  manifest: {
    ...gpuStudio.manifest,
    version: "1.2.0",
    timing: {
      version: 1,
      geometry: "pixels",
      hardware: true,
      scaleSteps: true,
      workflowAliases: Object.fromEntries(
        [standard, "h3-v4-rocm-qkv-safe-configurable", oldFast, fast].map(
          (w) => [w, "h3-native-qkv-safe"]
        )
      )
    }
  },
  timingFeatures({ model, kind, input, node, previous, stage }) {
    const p = input.params, profile = node?.model_profiles?.[model] || node?.profile || {}, refs = input.references.length;
    const hardware = Object.keys(profile).length ? hardwareSignature(profile) : node?.hardware || "", runtime_id = node?.runtime_id || "";
    const spec = gpuStudio.manifest.models.find((m) => m.id === model)?.studio?.runtime;
    if (!spec) throw new Error("Unknown GPU model");
    if (kind === "audio") {
      const length = p.text_chars || Math.max(1, [...input.prompt].length), language = p.language || (/[\u4e00-\u9fff]/.test(input.prompt) ? "zh" : "en"), voice = p.audio_settings?.instruction ?? p.instruction ?? "";
      return {
        kind,
        model,
        executor: "gpu",
        workflow: String(spec.workflow),
        width: length,
        height: 1,
        seconds: 0,
        steps: 0,
        video_mode: "tts",
        quality: language + "|" + sha(voice).slice(0, 12),
        refs: 0,
        ref_pixels: 0,
        hardware,
        profile,
        runtime_id,
        cold: stage === "start" && runtime_id ? !(previous?.runtime_id === runtime_id && previous.video_mode === "tts") : null
      };
    }
    const size = ratios[p.ratio || "16:9"];
    if (!size) throw new Error("Invalid GPU ratio");
    const offset = Number(p.quality ?? 480) === 768 ? 2 : 0, mode = pipeline(p, refs).split("|")[0];
    return {
      kind,
      model,
      executor: "gpu",
      workflow: p.sampling_steps === 4 ? "h3-turbo4-" + preset(p, refs) : node?.workflow || standard,
      width: p.width ?? size[offset],
      height: p.height ?? size[offset + 1],
      seconds: p.seconds ?? 5,
      steps: p.sampling_steps ?? (refs === 1 && Number(p.quality) === 768 && node?.workflow === "h3-v3-rocm-qkv-safe-fast4-i2v768" ? 4 : 20),
      video_mode: mode,
      quality: String(p.quality ?? 480),
      refs,
      ref_pixels: input.references.reduce((n, r) => n + r.width * r.height, 0),
      hardware,
      profile,
      runtime_id,
      cold: runtime_id ? !(previous?.runtime_id === runtime_id && pipeline(previous, previous.refs) === pipeline(p, refs)) : null
    };
  }
};

// plugins/gpu/src/queue.ts
var standard2 = "MiniMax H3";
var native = "h3-v6-native-inputs-turbo4";
var fast2 = ["h3-v5-rocm-qkv-safe-turbo4", native];
var readyModels = (node) => node.ready_models ?? [standard2];
function canRunQueueJob(node, job) {
  if (!readyModels(node).includes(job.model)) return false;
  if (job.model !== standard2) return true;
  const p = job.input.params;
  if (p.h3_inputs && Object.keys(p.h3_inputs).length && node.workflow !== native)
    return false;
  if (node.workflow === "h3-v3-rocm-qkv-safe-fast4-i2v768") return false;
  if ((p.sampling_steps ?? 20) === 4 && !fast2.includes(node.workflow || ""))
    return false;
  return (node.video_steps ?? [20]).includes(p.sampling_steps ?? 20);
}
var queueWorkload = (job) => job.kind === "audio" ? "tts" : pipeline(job.input.params, job.input.references.length);
var priorWorkload = (f) => f.kind === "audio" ? "tts" : pipeline(f, f.refs);
var gpuQueue = {
  ...gpuTiming,
  manifest: {
    ...gpuTiming.manifest,
    version: "1.3.0",
    queue: {
      version: 1,
      strategy: "slots",
      timingVersions: ["1.2.0", "1.3.0"]
    }
  },
  claimEligible(node, job, stamp2) {
    return node.execution_plan?.mode !== "parallel" && node.control === "active" && ["ready", "busy"].includes(node.stage) && stamp2 - node.lastseen <= 75 && node.can_accept !== false && canRunQueueJob(node, job);
  },
  queuePlan(context, tools) {
    const { jobs, stamp: stamp2 } = context;
    const expanded = context.nodes.flatMap(
      (n) => n.execution_plan?.mode === "parallel" ? (n.lanes || []).filter(
        (l) => ["ready", "busy"].includes(l.stage) && stamp2 - l.lastseen <= 75
      ).map((l) => ({
        ...n,
        stage: l.stage,
        lastseen: l.lastseen,
        runtime_id: l.runtime_id,
        ready_models: [l.model],
        lane_model: l.model,
        can_accept: l.can_accept
      })) : [n]
    );
    const alive = expanded.filter(
      (n) => ["ready", "busy"].includes(n.stage) && stamp2 - n.lastseen <= 75
    ), active = alive.filter((n) => n.control === "active");
    const liveJobs = jobs.filter(
      (j) => j.status === "running" && (j.kind === "image" || alive.some((n) => n.id === j.node))
    ).map((j) => j.id);
    const slots = active.map((node) => {
      const previous = context.history.find(
        (r) => r.node === node.id && (!node.lane_model || r.features.model === node.lane_model)
      );
      let mode = previous && previous.features.runtime_id === node.runtime_id ? priorWorkload(previous.features) : null;
      const running = jobs.find(
        (j) => j.node === node.id && j.status === "running" && (!node.lane_model || j.model === node.lane_model)
      );
      let low = 0, median = null, high = null;
      if (running) {
        const row = context.runs[running.id];
        mode = row?.features ? priorWorkload(row.features) : queueWorkload(running);
        const eta = tools.remaining(running);
        if (eta.high != null && !eta.overdue) {
          low = eta.low ?? 0;
          median = eta.median ?? 0;
          high = eta.high;
        }
      } else if (node.stage === "ready") {
        if (node.can_accept !== false) median = high = 0;
      } else if (previous?.finished != null && previous.finished >= node.lastseen) {
        median = 0;
        high = 5;
      }
      return { node, low, median, high, modes: [mode] };
    });
    return tools.schedule({
      waiting: jobs.filter((j) => j.status === "queued"),
      slots,
      mode: queueWorkload,
      eligible: (slot, job) => canRunQueueJob(slot.node, job),
      unavailable: (job) => job.model === standard2 && active.some((n) => readyModels(n).includes(job.model)) ? "worker_update" : "waiting_gpu",
      predict: (job, slot, mode) => {
        if (!tools.supports(job))
          return { source: "none", samples: 0, confidence: "none", version: 4 };
        const f = tools.features(job, slot.node);
        if (slot.node?.runtime_id) f.cold = mode !== queueWorkload(job);
        return tools.planning(f, slot.node?.id, liveJobs);
      }
    });
  }
};

// plugins/gpu/src/reference-media.ts
import { spawn } from "node:child_process";
import { stat, rm } from "node:fs/promises";
import {
  ReferenceImportError,
  ReferenceImportBusyError
} from "fumiao:packages/plugin-sdk/src/references.js";
import { roundDecimal } from "fumiao:packages/plugin-sdk/src/decimal.js";
var formats = "mov,matroska,webm,wav,mp3,flac,ogg,aac";
var mediaCommand = (command, args, timeout, signal) => new Promise((resolve, reject) => {
  signal.throwIfAborted();
  const child = spawn(command, args, { stdio: ["ignore", "pipe", "pipe"] });
  const output = [];
  let size = 0, error;
  const stop = (reason) => {
    error ??= reason;
    child.kill("SIGKILL");
  };
  const abort = () => stop(
    signal.reason instanceof Error ? signal.reason : new Error("Media conversion aborted")
  );
  const timer = setTimeout(
    () => stop(new Error("Media conversion timed out")),
    timeout
  );
  signal.addEventListener("abort", abort, { once: true });
  if (signal.aborted) abort();
  child.stdout.on("data", (chunk) => {
    size += chunk.length;
    if (size > 1 << 20) stop(new Error("Media probe output exceeds limit"));
    else output.push(chunk);
  });
  child.stderr.on("data", (chunk) => {
    size += chunk.length;
    if (size > 1 << 20) stop(new Error("Media process output exceeds limit"));
  });
  child.once("error", (e) => {
    error ??= e;
  });
  child.once("close", (code) => {
    clearTimeout(timer);
    signal.removeEventListener("abort", abort);
    if (error || code !== 0)
      reject(error ?? new Error("Media process failed"));
    else resolve(Buffer.concat(output).toString("utf8"));
  });
});
var numeric = (v) => {
  const value = Number(v);
  return Number.isFinite(value) ? value : 0;
};
async function probe(path, signal, command) {
  try {
    const value = JSON.parse(
      await command(
        "ffprobe",
        [
          "-v",
          "error",
          "-protocol_whitelist",
          "file,pipe",
          "-format_whitelist",
          formats,
          "-show_entries",
          "format=duration:stream=codec_type,width,height,duration,avg_frame_rate:stream_disposition=attached_pic",
          "-of",
          "json",
          path
        ],
        2e4,
        signal
      )
    );
    const streams = value.streams || [];
    return {
      seconds: Math.max(
        numeric(value.format?.duration),
        ...streams.map((s) => numeric(s.duration))
      ),
      video: streams.find(
        (s) => s.codec_type === "video" && !s.disposition?.attached_pic
      ),
      audio: streams.find((s) => s.codec_type === "audio")
    };
  } catch (e) {
    signal.throwIfAborted();
    throw new ReferenceImportError("\u65E0\u6CD5\u8BFB\u53D6\u8FD9\u4E2A\u89C6\u9891\u6216\u97F3\u9891\u6587\u4EF6");
  }
}
async function normalizeReference(input, output, kind, signal, command = mediaCommand) {
  const meta = await probe(input, signal, command);
  if (meta.seconds < 1.99 || meta.seconds > 15.05)
    throw new ReferenceImportError("\u53C2\u8003\u89C6\u9891\u548C\u97F3\u9891\u7684\u65F6\u957F\u9700\u4E3A 2\u201315 \u79D2");
  if (kind === "video" && !meta.video)
    throw new ReferenceImportError("\u8BF7\u9009\u62E9\u5305\u542B\u753B\u9762\u7684\u89C6\u9891\u6587\u4EF6");
  if (kind === "audio" && !meta.audio)
    throw new ReferenceImportError("\u8BF7\u9009\u62E9\u5305\u542B\u58F0\u97F3\u7684\u97F3\u9891\u6587\u4EF6");
  if (meta.video && numeric(meta.video.width) * numeric(meta.video.height) > 33177600)
    throw new ReferenceImportError("\u53C2\u8003\u89C6\u9891\u753B\u9762\u8FC7\u5927\uFF0C\u8BF7\u5148\u7F29\u5C0F\u540E\u4E0A\u4F20");
  const args = [
    "-v",
    "error",
    "-nostdin",
    "-y",
    "-protocol_whitelist",
    "file,pipe",
    "-format_whitelist",
    formats,
    "-i",
    input,
    "-t",
    "15.5",
    "-map_metadata",
    "-1",
    "-map_chapters",
    "-1"
  ];
  if (kind === "video")
    args.push(
      "-map",
      "0:v:0",
      "-map",
      "0:a:0?",
      "-vf",
      "scale=w='min(1280,iw)':h='min(1280,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,fps=24,setsar=1",
      "-c:v",
      "libx264",
      "-preset",
      "veryfast",
      "-crf",
      "22",
      "-pix_fmt",
      "yuv420p",
      "-threads",
      "2",
      "-c:a",
      "aac",
      "-ar",
      "32000",
      "-ac",
      "2",
      "-movflags",
      "+faststart"
    );
  else
    args.push(
      "-map",
      "0:a:0",
      "-vn",
      "-c:a",
      "pcm_s16le",
      "-ar",
      "32000",
      "-ac",
      "2"
    );
  try {
    try {
      await command("ffmpeg", [...args, output], 9e4, signal);
    } catch (e) {
      signal.throwIfAborted();
      throw new ReferenceImportError("\u7D20\u6750\u8F6C\u6362\u5931\u8D25\uFF0C\u8BF7\u66F4\u6362\u6587\u4EF6\u540E\u91CD\u8BD5");
    }
    const result = await probe(output, signal, command), size = (await stat(output)).size;
    if (result.seconds < 1.99 || result.seconds > 15.05 || size > 64 << 20)
      throw new ReferenceImportError(
        "\u53C2\u8003\u7D20\u6750\u8D85\u8FC7\u65F6\u957F\u6216\u5927\u5C0F\u9650\u5236\uFF0C\u8BF7\u5148\u88C1\u77ED\u540E\u4E0A\u4F20"
      );
    return {
      seconds: roundDecimal(result.seconds, 4),
      fps: kind === "video" ? 24 : 0,
      has_audio: !!result.audio,
      w: result.video?.width || 0,
      h: result.video?.height || 0,
      mime: kind === "video" ? "video/mp4" : "audio/wav",
      size
    };
  } catch (e) {
    await rm(output, { force: true });
    signal.throwIfAborted();
    if (e instanceof ReferenceImportError) throw e;
    throw new ReferenceImportError("\u7D20\u6750\u8F6C\u6362\u5931\u8D25\uFF0C\u8BF7\u66F4\u6362\u6587\u4EF6\u540E\u91CD\u8BD5");
  }
}
var ReferenceImporter = class {
  constructor(concurrency = 2, maxQueued = 32, convert = normalizeReference) {
    this.concurrency = concurrency;
    this.maxQueued = maxQueued;
    this.convert = convert;
    if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 8 || !Number.isInteger(maxQueued) || maxQueued < 0)
      throw Error("Invalid reference conversion limits");
  }
  concurrency;
  maxQueued;
  convert;
  active = 0;
  queue = [];
  async import(input, output, kind, signal) {
    signal.throwIfAborted();
    if (this.active >= this.concurrency && this.queue.length >= this.maxQueued)
      throw new ReferenceImportBusyError("Reference conversion queue is full");
    return new Promise((resolve, reject) => {
      const job = {
        run: () => this.convert(input, output, kind, signal),
        signal,
        resolve,
        reject,
        abort: () => {
          const i = this.queue.indexOf(job);
          if (i >= 0) {
            this.queue.splice(i, 1);
            reject(signal.reason);
          }
        }
      };
      signal.addEventListener("abort", job.abort, { once: true });
      this.queue.push(job);
      this.drain();
    });
  }
  drain() {
    while (this.active < this.concurrency && this.queue.length) {
      const job = this.queue.shift();
      job.signal.removeEventListener("abort", job.abort);
      if (job.signal.aborted) {
        job.reject(job.signal.reason);
        continue;
      }
      this.active++;
      void Promise.resolve().then(job.run).finally(() => {
        this.active--;
        this.drain();
      }).then(job.resolve, job.reject);
    }
  }
};
var referenceImporter = new ReferenceImporter();

// plugins/gpu/src/references.ts
var gpuReferences = {
  ...gpuQueue,
  manifest: {
    ...gpuQueue.manifest,
    version: "1.4.0",
    queue: {
      ...gpuQueue.manifest.queue,
      timingVersions: ["1.2.0", "1.3.0", "1.4.0"]
    },
    referenceImports: [
      { version: 1, id: "h3", kinds: ["video", "audio"], maxBytes: 96 << 20 }
    ]
  },
  importReference: (input, output, kind, signal) => referenceImporter.import(input, output, kind, signal)
};

// plugins/gpu/src/inputs.ts
import { randomBytes } from "node:crypto";
import {
  InputPreparationError
} from "fumiao:packages/plugin-sdk/src/preparation.js";
var fail = (message) => {
  throw new InputPreparationError(message);
};
var unique = (ids) => [...new Set(ids)];
function canonicalInput(input) {
  const h32 = input.params.h3;
  return {
    ...input,
    references: input.references.map((id) => id.toLowerCase()),
    params: {
      ...input.params,
      ...h32 ? {
        h3: {
          ...h32,
          first_frame: h32.first_frame?.toLowerCase() ?? null,
          last_frame: h32.last_frame?.toLowerCase() ?? null,
          video_audio: h32.video_audio.map((id) => id.toLowerCase())
        }
      } : {}
    }
  };
}
var ratios2 = {
  "16:9": [864, 480, 1344, 768],
  "9:16": [480, 864, 768, 1344],
  "1:1": [480, 480, 768, 768],
  "4:3": [640, 480, 1024, 768],
  "3:4": [480, 640, 768, 1024],
  "21:9": [1120, 480, 1568, 672]
};
function referenceIds(input, canonical = true) {
  if (canonical) input = canonicalInput(input);
  const options = input.params.h3;
  if (!options) return input.references;
  if (input.model !== "MiniMax H3") fail("\u5F53\u524D\u6A21\u578B\u4E0D\u652F\u6301 H3 \u8F93\u5165\u6A21\u5F0F");
  if (options.mode === "frames") {
    if (input.hasReferencePacks) fail("\u9996\u5C3E\u5E27\u6A21\u5F0F\u8BF7\u5728\u69FD\u4F4D\u4E2D\u76F4\u63A5\u9009\u62E9\u56FE\u7247");
    if (options.video_audio.length) fail("\u9996\u5C3E\u5E27\u6A21\u5F0F\u53EA\u63A5\u6536\u56FE\u7247");
    const ids = unique(
      [options.first_frame, options.last_frame].filter(Boolean)
    );
    if (input.references.some((id) => !ids.includes(id)))
      fail("\u9996\u5C3E\u5E27\u6A21\u5F0F\u8BF7\u5728\u5BF9\u5E94\u69FD\u4F4D\u9009\u62E9\u56FE\u7247");
    return ids;
  }
  if (options.first_frame || options.last_frame)
    fail("\u8BF7\u5728\u9996\u5C3E\u5E27\u6A21\u5F0F\u6307\u5B9A\u9996\u5E27\u548C\u5C3E\u5E27");
  if (unique(input.references).length !== input.references.length)
    fail("\u53C2\u8003\u7D20\u6750\u4E0D\u80FD\u91CD\u590D");
  return input.references;
}
function prepareNative(input, assets, canonical = true) {
  if (canonical) input = canonicalInput(input);
  const options = input.params.h3;
  if (!options) return null;
  const ids = referenceIds(input, false);
  const files = ids.map((id) => {
    const row = assets.find((a) => a.id === id);
    if (!row || !["ref", "ref_video", "ref_audio"].includes(row.role))
      return fail("\u53C2\u8003\u7D20\u6750\u4E0D\u5B58\u5728\u6216\u683C\u5F0F\u4E0D\u53D7\u652F\u6301");
    const kind = { ref: "image", ref_video: "video", ref_audio: "audio" }[row.role];
    if (options.mode === "frames" && kind !== "image")
      fail("\u9996\u5C3E\u5E27\u6A21\u5F0F\u53EA\u63A5\u6536\u56FE\u7247");
    const item = {
      id,
      kind,
      mime: row.mime,
      w: row.width,
      h: row.height,
      suffix: { image: "png", video: "mp4", audio: "wav" }[kind]
    };
    if (kind !== "image") {
      if (!row.reference) fail("\u53C2\u8003\u7D20\u6750\u4FE1\u606F\u7F3A\u5931\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20");
      Object.assign(item, row.reference);
    }
    return item;
  });
  for (const kind of ["image", "video", "audio"]) {
    const limit = referenceLimits.counts[kind];
    const selected = files.filter((f) => f.kind === kind);
    if (selected.length > limit)
      fail(
        {
          image: "\u6700\u591A\u9009\u62E9 9 \u5F20\u56FE\u7247",
          video: "\u6700\u591A\u9009\u62E9 3 \u6BB5\u89C6\u9891",
          audio: "\u6700\u591A\u9009\u62E9 3 \u6BB5\u97F3\u9891"
        }[kind]
      );
    if (kind !== "image" && (selected.some(
      (f) => !(f.seconds >= referenceLimits.minSeconds - 0.01 && f.seconds <= referenceLimits.maxSeconds + 0.05)
    ) || selected.reduce((sum, f) => sum + f.seconds, 0) > referenceLimits.maxSeconds + 0.05))
      fail("\u540C\u7C7B\u53C2\u8003\u89C6\u9891\u6216\u97F3\u9891\u7684\u603B\u65F6\u957F\u4E0D\u80FD\u8D85\u8FC7 15 \u79D2");
    if (kind === "video" && selected.some(
      (f) => f.seconds > input.params.seconds + 0.05 || f.fps !== 24
    ))
      fail("\u751F\u6210\u65F6\u957F\u4E0D\u80FD\u77ED\u4E8E\u53C2\u8003\u89C6\u9891\uFF0C\u8BF7\u8C03\u6574\u65F6\u957F\u6216\u88C1\u77ED\u53C2\u8003\u89C6\u9891");
  }
  if (files.length > referenceLimits.max) fail("\u6700\u591A\u9009\u62E9 12 \u4E2A\u53C2\u8003\u7D20\u6750");
  if (options.video_audio.some(
    (id) => !files.some((f) => f.id === id && f.kind === "video" && f.has_audio)
  ))
    fail("\u6240\u9009\u89C6\u9891\u6CA1\u6709\u53EF\u5F15\u7528\u7684\u58F0\u97F3");
  if (options.mode === "frames" && files.length === 2) {
    const [a, b] = files;
    if (!a.w || !a.h || !b.w || !b.h || Math.abs(Math.log(a.w / a.h / (b.w / b.h))) > 0.035)
      fail("\u8BF7\u4F7F\u7528\u6BD4\u4F8B\u76F8\u540C\u7684\u9996\u5C3E\u5E27\u56FE\u7247");
  }
  return {
    version: 1,
    mode: options.mode,
    first_frame: options.first_frame ?? null,
    last_frame: options.last_frame ?? null,
    video_audio: unique(options.video_audio),
    files
  };
}
function prepareInput(input, assets, strip = (value) => value.trim()) {
  input = canonicalInput(input);
  if (input.params.h3 && input.model !== "MiniMax H3")
    fail("\u5F53\u524D\u6A21\u578B\u4E0D\u652F\u6301 H3 \u8F93\u5165\u6A21\u5F0F");
  if (input.model === "breeze-tts-2") {
    if ([...input.prompt].length > 300) fail("\u6A21\u578B\u53C2\u6570\u65E0\u6548");
    return {
      references: input.references,
      params: {
        ...input.params,
        instruction: strip(input.params.instruction || "") || (/[\u4e00-\u9fff]/.test(input.prompt) ? "\u58F0\u97F3\u6E05\u6670\u81EA\u7136\u3001\u8BED\u901F\u9002\u4E2D\uFF0C\u4F7F\u7528\u666E\u901A\u8BDD\u6717\u8BFB\u3002" : "A clear, natural narrator speaking at a moderate pace."),
        seed: input.params.seed ?? randomBytes(4).readUInt32BE() & 2147483647
      }
    };
  }
  if (input.model !== "MiniMax H3")
    return { params: input.params, references: input.references };
  const native2 = prepareNative(input, assets), ids = native2 ? native2.files.map((f) => f.id) : input.references;
  if (!native2 && ids.length > 9) fail("\u6700\u591A\u9009\u62E9 9 \u5F20\u53C2\u8003\u56FE\u7247");
  const selected = ids.map((id) => {
    const row = assets.find((a) => a.id === id);
    if (!row || !native2 && row.role !== "ref") return fail("\u53C2\u8003\u56FE\u5DF2\u4E0D\u5B58\u5728");
    return row;
  });
  let ratio = native2?.mode === "frames" && selected.length ? "auto" : input.params.ratio;
  if (ratio === "auto") {
    const visual = selected.find((a) => a.width && a.height), target = visual ? visual.width / visual.height : 16 / 9;
    ratio = Object.keys(ratios2).reduce((best, key) => {
      const difference = (r) => {
        const [w, h] = r.split(":").map(Number);
        return Math.abs(Math.log(target / (w / h)));
      };
      return difference(key) < difference(best) ? key : best;
    });
  }
  const offset = input.params.quality === 480 ? 0 : 2, [width, height] = ratios2[ratio].slice(offset, offset + 2), { h3: h32, ...params2 } = input.params;
  return {
    references: ids,
    params: {
      ...params2,
      ratio,
      width,
      height,
      seed: params2.seed ?? Number(randomBytes(8).readBigUInt64BE() & (1n << 53n) - 1n),
      ...native2 ? { h3_inputs: native2 } : {}
    }
  };
}

// plugins/gpu/src/artifacts.ts
import { createHash as createHash2, timingSafeEqual } from "node:crypto";
import { mkdtemp, writeFile, rm as rm2 } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  ArtifactValidationError
} from "fumiao:packages/plugin-sdk/src/preparation.js";
import { roundDecimal as roundDecimal2 } from "fumiao:packages/plugin-sdk/src/decimal.js";
var fail2 = (message) => {
  throw new ArtifactValidationError(message);
};
function inputFingerprint(value) {
  if (!value || !Object.keys(value).length) return "";
  const sorted = (v) => Array.isArray(v) ? "[" + v.map(sorted).join(",") + "]" : v && typeof v === "object" ? "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + sorted(v[k])).join(",") + "}" : JSON.stringify(v);
  return createHash2("sha256").update(
    sorted(value).replace(
      /[\u007f-\uffff]/g,
      (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0")
    )
  ).digest("hex");
}
var trimNumber = (value) => value.replace(new RegExp("^\\p{White_Space}+|\\p{White_Space}+$", "gu"), "");
function integer(value) {
  if (typeof value === "boolean") return Number(value);
  if (typeof value === "string") {
    const trimmed = trimNumber(value);
    if (!/^[+-]?\d(?:_?\d)*(?:\.0+)?$/.test(trimmed)) throw Error();
    value = Number(trimmed.replaceAll("_", ""));
  }
  if (typeof value !== "number" || !Number.isInteger(value)) throw Error();
  return value;
}
function boolean(value) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const v = value.toLowerCase();
    if (["1", "t", "true", "y", "yes", "on"].includes(v)) return true;
    if (["0", "f", "false", "n", "no", "off"].includes(v)) return false;
  }
  if (value === 0 || value === 1) return !!value;
  throw Error();
}
function receiptReport(text) {
  try {
    const value = JSON.parse(text || "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    const result = {};
    for (const [key, v] of Object.entries(value)) {
      if (v === null && key !== "recovered") continue;
      if (key === "h3_input_fingerprint") {
        if (typeof v !== "string" || !/^[a-f0-9]{64}$/.test(v)) throw Error();
        result[key] = v;
      } else if ([
        "sampling_steps",
        "peak_vram_bytes",
        "peak_allocated_vram_bytes"
      ].includes(key)) {
        const n = integer(v);
        if (n < (key === "sampling_steps" ? 1 : 0) || n > (key === "sampling_steps" ? 100 : 2 ** 50))
          throw Error();
        result[key] = n;
      } else if (["fast_mode", "cold", "recovered"].includes(key))
        result[key] = boolean(v);
      else if (["prepare_s", "generate_s", "finalize_s"].includes(key)) {
        if (typeof v !== "boolean" && typeof v !== "number" && typeof v !== "string")
          throw Error();
        let number = v;
        if (typeof v === "string") {
          const trimmed = trimNumber(v);
          if (trimmed.startsWith("_") || trimmed.endsWith("_") || trimmed.includes("__"))
            throw Error();
          number = trimmed.replaceAll("_", "");
          if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(
            number
          ))
            throw Error();
        }
        const n = Number(number);
        if (!Number.isFinite(n) || n < 0 || n > 172800) throw Error();
        result[key] = n;
      }
    }
    return result;
  } catch {
    return {};
  }
}
function validateReport(job, receipt) {
  const report = receiptReport(receipt.report), params2 = job.params;
  if (job.model === "MiniMax H3") {
    const expected = inputFingerprint(params2.h3_inputs), steps = params2.sampling_steps ?? 20;
    if (expected && report.h3_input_fingerprint !== expected)
      fail2("\u6210\u7247\u53C2\u8003\u6A21\u5F0F\u4E0E\u4EFB\u52A1\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u66F4\u65B0\u5B9E\u4F8B\u540E\u91CD\u8BD5");
    const observed = report.sampling_steps;
    if (observed === void 0 && steps !== 20 || observed !== void 0 && observed !== steps)
      fail2("\u6210\u7247\u91C7\u6837\u6B65\u6570\u4E0E\u4EFB\u52A1\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u66F4\u65B0\u5B9E\u4F8B\u540E\u91CD\u65B0\u751F\u6210");
    const fast3 = report.fast_mode;
    if (steps === 4 && fast3 !== true || fast3 !== void 0 && fast3 !== (steps === 4))
      fail2("\u6210\u7247\u5FEB\u901F\u6A21\u5F0F\u4E0E\u4EFB\u52A1\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u66F4\u65B0\u5B9E\u4F8B\u540E\u91CD\u65B0\u751F\u6210");
  }
  return report;
}
function validateDigest(bytes, receipt) {
  const digest = createHash2("sha256").update(bytes).digest("hex"), provided = receipt.sha256 || "";
  if (!/^[a-f0-9]{64}$/.test(provided) || !timingSafeEqual(Buffer.from(provided), Buffer.from(digest)))
    fail2("\u6210\u7247\u6458\u8981\u4E0D\u7B26");
}
function validateAudio(bytes) {
  try {
    const b = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (b.toString("ascii", 0, 4) !== "RIFF" || b.toString("ascii", 8, 12) !== "WAVE")
      throw Error();
    const end = Math.min(b.length, b.readUInt32LE(4) + 8);
    let format;
    for (let pos = 12; pos + 8 <= end; ) {
      const tag = b.toString("ascii", pos, pos + 4), size = b.readUInt32LE(pos + 4), start = pos + 8;
      if (tag === "fmt ") {
        if (size < 16 || start + size > end) throw Error();
        const type = b.readUInt16LE(start), channels = b.readUInt16LE(start + 2), rate = b.readUInt32LE(start + 4), width = Math.ceil(b.readUInt16LE(start + 14) / 8);
        if (type !== 1 && (type !== 65534 || size < 40 || !b.subarray(start + 24, start + 40).equals(Buffer.from("0100000000001000800000aa00389b71", "hex"))))
          throw Error();
        if (!channels || !width) throw Error();
        format = { channels, width, rate };
      } else if (tag === "data") {
        if (!format || format.channels !== 1 || format.width !== 2 || format.rate !== 24e3)
          throw Error();
        const frames = Math.floor(size / 2), duration = frames / 24e3;
        if (duration < 0.1 || duration >= 119.5 || start + frames * 2 > end)
          throw Error();
        let peak = 0;
        for (let i = start; i < start + frames * 2; i += 2)
          peak = Math.max(peak, Math.abs(b.readInt16LE(i)));
        if (peak < 32) throw Error();
        return {
          mime: "audio/wav",
          width: 0,
          height: 0,
          duration: roundDecimal2(duration, 3),
          sample_rate: 24e3,
          channels: 1,
          format: "wav"
        };
      }
      pos = start + size + size % 2;
    }
    throw Error();
  } catch {
    return fail2("\u8BED\u97F3\u672A\u901A\u8FC7\u5B8C\u6574\u6027\u6216\u65F6\u957F\u6821\u9A8C\uFF1B\u5982\u8FBE\u5230\u65F6\u957F\u4E0A\u9650\uFF0C\u8BF7\u7F29\u77ED\u6587\u5B57\u540E\u91CD\u8BD5");
  }
}
async function validateVideo(path, job, signal) {
  const opts = ["-v", "error", "-protocol_whitelist", "file,pipe", "-f", "mov"];
  try {
    const meta = JSON.parse(
      await mediaCommand(
        "ffprobe",
        [...opts, "-show_streams", "-show_format", "-of", "json", path],
        15e3,
        signal
      )
    ), v = meta.streams.find((s) => s.codec_type === "video"), a = meta.streams.find((s) => s.codec_type === "audio");
    const rotations = [
      v.tags?.rotate || 0,
      ...(v.side_data_list || []).filter((s) => "rotation" in s).map((s) => s.rotation)
    ];
    const frames = { 5: 124, 10: 243, 15: 362 }[job.params.seconds], rate = String(v.avg_frame_rate).split("/").map(Number);
    if (rotations.some(
      (angle) => !Number.isFinite(Number(angle)) || Number(angle) % 360 !== 0
    ) || !frames || v.width !== job.params.width || v.height !== job.params.height || v.codec_name !== "h264" || rate.length !== 2 || rate[1] === 0 || rate[0] / rate[1] !== 24 || Number(v.nb_frames) !== frames || a.codec_name !== "aac" || a.channels !== 2 || Number(a.sample_rate) !== 32e3 || Math.abs(Number(meta.format.duration) - frames / 24) > 0.16 || !Number.isFinite(Number(meta.format.duration)))
      throw Error();
    await mediaCommand(
      "ffmpeg",
      [
        "-nostdin",
        "-xerror",
        ...opts,
        "-threads",
        "2",
        "-i",
        path,
        "-map",
        "0:v:0",
        "-map",
        "0:a:0",
        "-f",
        "null",
        "-"
      ],
      9e4,
      signal
    );
  } catch {
    signal.throwIfAborted();
    fail2("\u6210\u7247\u672A\u901A\u8FC7\u5206\u8FA8\u7387\u3001\u97F3\u89C6\u9891\u6216\u5B8C\u6574\u89E3\u7801\u6821\u9A8C");
  }
}
var activeValidations = 0;
async function validateArtifact(job, bytes, receipt, signal, progress) {
  signal.throwIfAborted();
  const report = validateReport(job, receipt);
  const timing = Object.fromEntries(
    Object.entries(report).filter(
      ([key]) => [
        "prepare_s",
        "generate_s",
        "finalize_s",
        "peak_vram_bytes",
        "peak_allocated_vram_bytes",
        "cold",
        "recovered"
      ].includes(key)
    )
  );
  if (activeValidations >= 2)
    throw new ArtifactValidationError("\u8BF7\u6C42\u5904\u7406\u5931\u8D25", 503);
  activeValidations++;
  try {
    await progress?.("uploading");
    signal.throwIfAborted();
    if (!bytes.length) throw new ArtifactValidationError("\u6587\u4EF6\u4E3A\u7A7A", 400);
    if (bytes.length > 64 << 20)
      throw new ArtifactValidationError("\u6587\u4EF6\u8FC7\u5927", 413);
    validateDigest(bytes, receipt);
    await progress?.("validating");
    if (job.kind === "audio") return { metadata: validateAudio(bytes), timing };
    const directory = await mkdtemp(join(tmpdir(), "fumiao-gpu-result-"));
    try {
      const path = join(directory, "output");
      await writeFile(path, bytes, { mode: 384 });
      await validateVideo(path, job, signal);
      return {
        timing,
        metadata: {
          mime: "video/mp4",
          width: job.params.width,
          height: job.params.height,
          sampling_steps: job.params.sampling_steps ?? 20,
          fast_mode: job.params.sampling_steps === 4,
          ...report.h3_input_fingerprint ? { h3_input_fingerprint: report.h3_input_fingerprint } : {}
        }
      };
    } finally {
      await rm2(directory, { recursive: true, force: true });
    }
  } finally {
    activeValidations--;
  }
}

// plugins/gpu/src/native.ts
var uuid = {
  type: "string",
  pattern: "^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$"
};
var h3 = {
  type: ["object", "null"],
  additionalProperties: false,
  required: ["mode"],
  properties: {
    mode: { enum: ["reference", "frames"] },
    first_frame: { ...uuid, type: ["string", "null"], default: null },
    last_frame: { ...uuid, type: ["string", "null"], default: null },
    video_audio: { type: "array", maxItems: 3, items: uuid, default: [] }
  }
};
var h3Inputs = {
  type: "object",
  additionalProperties: false,
  required: [
    "version",
    "mode",
    "first_frame",
    "last_frame",
    "video_audio",
    "files"
  ],
  properties: {
    ...h3.properties,
    version: { const: 1 },
    files: {
      type: "array",
      maxItems: 12,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["id", "kind", "mime", "w", "h", "suffix"],
        properties: {
          id: uuid,
          kind: { enum: ["image", "video", "audio"] },
          mime: { type: "string" },
          w: { type: "integer", minimum: 0 },
          h: { type: "integer", minimum: 0 },
          suffix: { enum: ["png", "mp4", "wav"] },
          seconds: { type: "number", minimum: 0 },
          fps: { type: "number", minimum: 0 },
          has_audio: { type: "boolean" },
          name: { type: "string", maxLength: 120 }
        }
      }
    }
  }
};
var gpuNative = {
  ...gpuReferences,
  manifest: {
    ...gpuReferences.manifest,
    version: "1.5.0",
    inputPreparation: { version: 1 },
    artifactValidation: { version: 1 },
    queue: {
      ...gpuReferences.manifest.queue,
      timingVersions: ["1.2.0", "1.3.0", "1.4.0", "1.5.0"]
    },
    models: gpuReferences.manifest.models.map((m) => {
      if (m.id !== "MiniMax H3") return { ...m, preparedSchema: m.inputSchema };
      const properties = m.inputSchema.properties, base = {
        ...properties,
        ratio: {
          ...properties.ratio,
          enum: [...properties.ratio.enum, "auto"]
        }
      };
      return {
        ...m,
        inputSchema: {
          ...m.inputSchema,
          "x-references": { types: ["image", "video", "audio"], max: 12 },
          properties: { ...base, h3 }
        },
        preparedSchema: {
          type: "object",
          additionalProperties: false,
          required: [
            "ratio",
            "quality",
            "seconds",
            "sampling_steps",
            "seed",
            "width",
            "height"
          ],
          properties: {
            ...properties,
            width: { type: "integer", minimum: 1 },
            height: { type: "integer", minimum: 1 },
            h3_inputs: h3Inputs
          }
        }
      };
    })
  },
  referenceIds,
  prepareInput,
  validateArtifact
};

// plugins/gpu/src/original.ts
import {
  OriginalSubmissionError,
  originalParent
} from "fumiao:packages/plugin-sdk/src/index.js";
var fail3 = (message) => {
  throw new OriginalSubmissionError(message);
};
var params = (d) => d.kind === "audio" ? {
  instruction: d.instruction,
  ...d.seed === null ? {} : { seed: d.seed }
} : {
  ratio: d.ratio,
  quality: d.quality,
  seconds: d.seconds,
  sampling_steps: d.sampling_steps,
  ...d.seed === null ? {} : { seed: d.seed },
  h3: d.h3
};
function createGpuOriginal(strip = (value) => value.trim()) {
  const request = (d) => ({
    model: d.model,
    kind: d.kind,
    prompt: strip(d.prompt),
    params: params(d),
    references: d.refs,
    hasReferencePacks: d.asset_packs.length > 0
  });
  return {
    ...gpuNative,
    manifest: {
      ...gpuNative.manifest,
      version: "1.6.0",
      originalSubmission: { version: 1 },
      queue: {
        ...gpuNative.manifest.queue,
        timingVersions: [...gpuNative.manifest.queue.timingVersions, "1.6.0"]
      }
    },
    originalSubmission: {
      namespace: (d) => d.kind === "audio" ? "-audio" : "",
      validate(d, phase) {
        if (phase === "before-packs" && d.h3?.mode === "frames" && d.asset_packs.length)
          fail3("\u9996\u5C3E\u5E27\u6A21\u5F0F\u8BF7\u5728\u69FD\u4F4D\u4E2D\u76F4\u63A5\u9009\u62E9\u56FE\u7247");
        if (phase === "before-retry" && d.kind === "video") {
          if (!strip(d.prompt) || !videoQualities.includes(d.quality) || !videoSeconds.includes(d.seconds))
            fail3("\u8BF7\u68C0\u67E5\u63D0\u793A\u8BCD\u3001\u6E05\u6670\u5EA6\u548C\u65F6\u957F");
          if (d.ratio !== "auto" && !Object.hasOwn(ratios2, d.ratio))
            fail3("\u672A\u77E5\u753B\u5E45");
        }
        if (phase === "prepare" && d.kind === "audio" && !strip(d.prompt))
          fail3("\u8BF7\u8F93\u5165\u8981\u6717\u8BFB\u7684\u6587\u5B57");
      },
      plan(d) {
        const native2 = !!d.h3;
        const refs = d.kind === "audio" ? [] : referenceIds(request(d));
        if (!native2 && refs.length > 9) fail3("\u6700\u591A\u9009\u62E9 9 \u5F20\u53C2\u8003\u56FE\u7247");
        return {
          namespace: d.kind === "audio" ? "-audio" : "",
          refs,
          roles: native2 ? ["ref", "ref_video", "ref_audio"] : ["ref"],
          missing: {
            status: 400,
            message: native2 ? "\u53C2\u8003\u7D20\u6750\u4E0D\u5B58\u5728\u6216\u683C\u5F0F\u4E0D\u53D7\u652F\u6301" : "\u53C2\u8003\u56FE\u5DF2\u4E0D\u5B58\u5728"
          },
          parentKind: d.kind === "audio" ? "audio" : "any"
        };
      },
      async prepare(d, r) {
        const ids = new Map(r.references.map((a) => [a.publicId, a.id]));
        const h32 = d.h3 ? {
          ...d.h3,
          first_frame: d.h3.first_frame ? ids.get(d.h3.first_frame) : null,
          last_frame: d.h3.last_frame ? ids.get(d.h3.last_frame) : null,
          video_audio: d.h3.video_audio.map(
            (id) => ids.get(id) || id
          )
        } : null;
        const prepared = prepareInput(
          request({ ...d, refs: d.refs.map((id) => ids.get(id) || id), h3: h32 }),
          r.references,
          strip
        );
        if (d.kind === "audio") originalParent(d, r.parent, "audio");
        await r.capacity();
        if (d.kind === "video") {
          originalParent(d, r.parent, "any");
          if (!d.provided.includes("sampling_steps") && r.parent?.model === d.model && [4, 16, 20, 32, 50].includes(r.parent.view.sampling_steps))
            prepared.params.sampling_steps = r.parent.view.sampling_steps;
        }
        const p = prepared.params, publicIds = new Map(r.references.map((a) => [a.id, a.publicId]));
        const native2 = p.h3_inputs ? {
          ...p.h3_inputs,
          first_frame: publicIds.get(p.h3_inputs.first_frame) || null,
          last_frame: publicIds.get(p.h3_inputs.last_frame) || null,
          video_audio: p.h3_inputs.video_audio.map(
            (id) => publicIds.get(id)
          ),
          files: p.h3_inputs.files.map((file) => ({
            ...file,
            id: publicIds.get(file.id)
          }))
        } : {};
        return {
          ...prepared,
          view: d.kind === "audio" ? {
            ratio: "audio",
            quality: 0,
            seconds: 0,
            sampling_steps: 20,
            seed: p.seed,
            width: 0,
            height: 0,
            image_quality: "standard",
            audio_settings: { instruction: p.instruction },
            h3_inputs: {}
          } : {
            ratio: p.ratio,
            quality: p.quality,
            seconds: p.seconds,
            sampling_steps: p.sampling_steps,
            seed: p.seed,
            width: p.width,
            height: p.height,
            image_quality: "medium",
            audio_settings: {},
            h3_inputs: native2
          }
        };
      }
    }
  };
}
var gpuOriginal = createGpuOriginal();

// plugins/gpu/src/estimate.ts
import {
  OriginalSubmissionError as OriginalSubmissionError2
} from "fumiao:packages/plugin-sdk/src/index.js";
var fail4 = (message) => {
  throw new OriginalSubmissionError2(message);
};
var gpuEstimate = {
  ...gpuOriginal,
  manifest: {
    ...gpuOriginal.manifest,
    version: "1.7.0",
    originalEstimate: { version: 1 },
    queue: {
      ...gpuOriginal.manifest.queue,
      timingVersions: [...gpuOriginal.manifest.queue.timingVersions, "1.7.0"]
    }
  },
  originalEstimate: {
    eligible: (node, job, stamp2) => node.control === "active" && ["ready", "busy"].includes(node.stage) && stamp2 - node.lastseen <= 75 && canRunQueueJob(node, job),
    async prepare(d, r) {
      let ratio = d.ratio, native2 = null, refs;
      if (d.h3) {
        if (d.kind !== "video" || !["", "MiniMax H3"].includes(d.model))
          fail4("\u5F53\u524D\u6A21\u578B\u4E0D\u652F\u6301 H3 \u8F93\u5165\u6A21\u5F0F");
        await r.authorize();
        const request = {
          model: "MiniMax H3",
          kind: "video",
          prompt: "",
          params: { seconds: d.seconds, h3: d.h3 },
          references: d.refs,
          hasReferencePacks: false
        };
        const ids2 = referenceIds(request, false);
        refs = await r.references(ids2, ["ref", "ref_video", "ref_audio"], {
          status: 400,
          message: "\u53C2\u8003\u7D20\u6750\u4E0D\u5B58\u5728\u6216\u683C\u5F0F\u4E0D\u53D7\u652F\u6301"
        });
        native2 = prepareNative(
          request,
          refs.map((a) => ({ ...a, id: a.publicId })),
          false
        );
        if (native2?.mode === "frames" && native2.files.length) {
          const image = native2.files[0], aspect = image.w / image.h;
          ratio = Object.keys(ratios2).reduce((best, key) => {
            const distance = (v) => {
              const [w, h] = v.split(":").map(Number);
              return Math.abs(Math.log(aspect / (w / h)));
            };
            return distance(key) < distance(best) ? key : best;
          });
        }
      }
      if (d.kind === "audio") {
        if (d.model !== "breeze-tts-2" || !["zh", "en"].includes(d.language))
          fail4("\u672A\u77E5\u8BED\u97F3\u53C2\u6570");
        return {
          model: d.model,
          kind: "audio",
          references: [],
          params: {
            text_chars: d.text_chars,
            language: d.language,
            instruction: d.audio_instruction.trim() || (d.language === "zh" ? "\u58F0\u97F3\u6E05\u6670\u81EA\u7136\u3001\u8BED\u901F\u9002\u4E2D\uFF0C\u4F7F\u7528\u666E\u901A\u8BDD\u6717\u8BFB\u3002" : "A clear, natural narrator speaking at a moderate pace.")
          }
        };
      }
      if (!["video", "image"].includes(d.kind) || !Object.hasOwn(ratios2, ratio))
        fail4("\u672A\u77E5\u751F\u6210\u53C2\u6570");
      if (d.kind !== "video" || !["", "MiniMax H3"].includes(d.model))
        fail4("\u672A\u77E5\u751F\u6210\u6A21\u578B");
      if (![480, 768].includes(d.quality) || ![5, 10, 15].includes(d.seconds))
        fail4("\u672A\u77E5\u751F\u6210\u53C2\u6570");
      refs ??= await r.references(d.refs);
      const ids = new Map(refs.map((a) => [a.publicId, a.id]));
      if (native2)
        native2 = {
          ...native2,
          first_frame: ids.get(native2.first_frame) ?? null,
          last_frame: ids.get(native2.last_frame) ?? null,
          video_audio: native2.video_audio.map((id) => ids.get(id)),
          files: native2.files.map((f) => ({ ...f, id: ids.get(f.id) }))
        };
      const offset = d.quality === 480 ? 0 : 2, [width, height] = ratios2[ratio].slice(offset, offset + 2);
      return {
        model: "MiniMax H3",
        kind: "video",
        references: refs.map((a) => a.id),
        params: {
          ratio,
          quality: d.quality,
          seconds: d.seconds,
          sampling_steps: d.sampling_steps,
          width,
          height,
          ...native2 ? { h3_inputs: native2 } : {}
        }
      };
    }
  }
};

// plugins/gpu/src/state.ts
import {
  publicKeys
} from "fumiao:packages/plugin-sdk/src/index.js";
var models = JSON.parse(
  '{\n  "MiniMax H3": {\n    "label": "MiniMax H3",\n    "slug": "minimax-h3",\n    "kind": "video",\n    "adapter": "h3",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 96,\n    "min_ram_gib": 128,\n    "disk_gib": 155,\n    "min_python": [\n      3,\n      12\n    ],\n    "manifest": "engine/assets/models.lock.json",\n    "cache_env": "H3_CACHE",\n    "cache_dir": "fumiao-h3",\n    "model_subdir": "models",\n    "persistence_priority": 0,\n    "precision": "bf16",\n    "workflow": "h3-v3-rocm-qkv-safe"\n  },\n  "breeze-tts-2": {\n    "label": "Breeze TTS 2",\n    "slug": "breeze-tts-2",\n    "kind": "audio",\n    "adapter": "breeze",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 12,\n    "min_ram_gib": 16,\n    "disk_gib": 20,\n    "min_python": [\n      3,\n      10\n    ],\n    "manifest": "breeze.lock.json",\n    "cache_env": "BREEZE_HOME",\n    "cache_dir": "fumiao-breeze",\n    "model_subdir": "checkpoint",\n    "persistence_priority": 10,\n    "precision": "bf16",\n    "workflow": "breeze-tts-2-eager-v1"\n  }\n}\n'
);
var gpuState = {
  ...gpuEstimate,
  manifest: {
    ...gpuEstimate.manifest,
    version: "1.8.0",
    queue: {
      ...gpuEstimate.manifest.queue,
      timingVersions: [...gpuEstimate.manifest.queue.timingVersions, "1.8.0"]
    },
    originalState: {
      version: 1,
      fields: ["ratios", "sizes", "gpu_models", "h3_limits"],
      queueLane: "kind",
      recovery: {
        maxAttempts: 2,
        retryNote: "\u5B9E\u4F8B\u79BB\u7EBF\uFF0C\u7B49\u5F85\u91CD\u65B0\u63A5\u5355",
        failureNote: "\u5B9E\u4F8B\u8FDE\u7EED\u4E2D\u65AD\uFF0C\u8BF7\u91CD\u65B0\u751F\u6210"
      }
    }
  },
  originalState: {
    configured: () => true,
    configuration: () => ({
      ratios: Object.keys(ratios2),
      sizes: ratios2,
      gpu_models: models,
      h3_limits: {
        images: 9,
        videos: 3,
        audios: 3,
        total: 12,
        clip_seconds: 15
      }
    }),
    project: (j) => ({
      ...j.state === "completed" ? {
        actual: publicKeys(
          j.metadata,
          j.kind === "audio" ? ["duration", "sample_rate", "channels", "format"] : ["sampling_steps", "fast_mode", "h3_input_fingerprint"]
        )
      } : {},
      ...["uploading", "validating"].includes(j.phase || "") && !["completed", "failed", "cancelled"].includes(j.state) ? { note: "\u6B63\u5728\u56DE\u4F20\u5E76\u6821\u9A8C\u6210\u7247" } : {}
    })
  }
};

// plugins/gpu/src/canvas.ts
var gpuCanvas = {
  ...gpuState,
  manifest: {
    ...gpuState.manifest,
    version: "1.9.0",
    queue: {
      ...gpuState.manifest.queue,
      timingVersions: [...gpuState.manifest.queue.timingVersions, "1.9.0"]
    },
    canvas: {
      version: 1,
      models: [
        {
          model: "MiniMax H3",
          kind: "video",
          defaultForKind: true,
          templatePriority: 0,
          durations: { values: videoSeconds, error: "MiniMax H3 \u65F6\u957F\u9009\u9879\u65E0\u6548" }
        }
      ]
    }
  }
};

// plugins/gpu/src/canvas-runs.ts
var gpuCanvasRuns = {
  ...gpuCanvas,
  manifest: {
    ...gpuCanvas.manifest,
    version: "1.10.0",
    queue: {
      ...gpuCanvas.manifest.queue,
      timingVersions: [...gpuCanvas.manifest.queue.timingVersions, "1.10.0"]
    },
    canvasSubmission: {
      version: 1,
      models: [
        {
          model: "MiniMax H3",
          kind: "video",
          defaultForKind: true,
          nativeH3: true
        },
        { model: "breeze-tts-2", kind: "audio", defaultForKind: true }
      ]
    }
  }
};

// plugins/gpu/src/original-text.ts
import { pythonStrip } from "fumiao:packages/plugin-sdk/src/python-text.js";
var gpuOriginalText = createGpuOriginal(pythonStrip);

// plugins/gpu/src/text.ts
var gpuText = {
  ...gpuCanvasRuns,
  originalSubmission: gpuOriginalText.originalSubmission,
  manifest: {
    ...gpuCanvasRuns.manifest,
    version: "1.11.0",
    queue: {
      ...gpuCanvasRuns.manifest.queue,
      timingVersions: [
        ...gpuCanvasRuns.manifest.queue.timingVersions,
        "1.11.0"
      ]
    }
  }
};

// plugins/gpu/src/paired-agent.ts
import {
  PairedAgentPlanError
} from "fumiao:packages/plugin-sdk/src/paired-agent.js";
var video = "MiniMax H3";
var audio = "breeze-tts-2";
var models2 = JSON.parse(
  '{\n  "MiniMax H3": {\n    "label": "MiniMax H3",\n    "slug": "minimax-h3",\n    "kind": "video",\n    "adapter": "h3",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 96,\n    "min_ram_gib": 128,\n    "disk_gib": 155,\n    "min_python": [\n      3,\n      12\n    ],\n    "manifest": "engine/assets/models.lock.json",\n    "cache_env": "H3_CACHE",\n    "cache_dir": "fumiao-h3",\n    "model_subdir": "models",\n    "persistence_priority": 0,\n    "precision": "bf16",\n    "workflow": "h3-v3-rocm-qkv-safe"\n  },\n  "breeze-tts-2": {\n    "label": "Breeze TTS 2",\n    "slug": "breeze-tts-2",\n    "kind": "audio",\n    "adapter": "breeze",\n    "backends": [\n      "cuda",\n      "rocm"\n    ],\n    "min_vram_gib": 12,\n    "min_ram_gib": 16,\n    "disk_gib": 20,\n    "min_python": [\n      3,\n      10\n    ],\n    "manifest": "breeze.lock.json",\n    "cache_env": "BREEZE_HOME",\n    "cache_dir": "fumiao-breeze",\n    "model_subdir": "checkpoint",\n    "persistence_priority": 10,\n    "precision": "bf16",\n    "workflow": "breeze-tts-2-eager-v1"\n  }\n}\n'
);
var fail5 = (detail) => {
  throw new PairedAgentPlanError(detail);
};
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var positive = (value) => typeof value === "number" && Number.isFinite(value) && value > 0;
var gpuPairedAgent = {
  provider: "gpu",
  version: 2,
  legacyModel: video,
  models: models2,
  canRun: canRunQueueJob,
  preflight: validateReport,
  hardware: hardwareSignature,
  plan(value, selected) {
    if (value.mode === "serial")
      return { mode: "serial", policy: "gpu-budget-v1" };
    if (value.mode !== "parallel") return fail5("\u6267\u884C\u8BA1\u5212\u65E0\u6548");
    const {
      lanes,
      reserve_vram_gib: reserves,
      ram_total_gib: totalRam,
      reserve_ram_gib: reserveRam
    } = value;
    if (!object(lanes)) return fail5("\u6267\u884C\u901A\u9053\u683C\u5F0F\u65E0\u6548");
    if (value.policy !== "gpu-budget-v1" || Object.keys(lanes).length !== 2 || ![video, audio].every(
      (model) => Object.hasOwn(lanes, model) && selected.includes(model)
    ))
      return fail5("\u5E76\u53D1\u6A21\u578B\u8BA1\u5212\u4E0E\u5B9E\u4F8B\u6388\u6743\u4E0D\u7B26");
    if (!object(reserves)) return fail5("\u663E\u5B58\u9884\u7B97\u683C\u5F0F\u65E0\u6548");
    if (!positive(totalRam) || totalRam > 65536 || !positive(reserveRam) || reserveRam > 65536)
      return fail5("\u7CFB\u7EDF\u5185\u5B58\u9884\u7B97\u65E0\u6548");
    const devices = /* @__PURE__ */ new Map();
    const budgets = /* @__PURE__ */ new Map();
    let ram = 0;
    for (const [model, lane] of Object.entries(lanes)) {
      if (!object(lane)) return fail5("\u6267\u884C\u901A\u9053\u683C\u5F0F\u65E0\u6548");
      const {
        backend,
        device,
        gpu_total_gib: total,
        gpu_budget_gib: gpu2,
        ram_budget_gib: memory
      } = lane;
      const spec = models2[model];
      if (typeof backend !== "string" || !spec.backends.includes(backend) || typeof device !== "number" || !Number.isInteger(device) || device < 0 || device >= 128)
        return fail5("\u5E76\u53D1\u8BBE\u5907\u65E0\u6548");
      if (!positive(total) || !positive(gpu2) || !positive(memory))
        return fail5("\u8D44\u6E90\u9884\u7B97\u65E0\u6548");
      if (total < spec.min_vram_gib || memory < spec.min_ram_gib)
        return fail5("\u6A21\u578B\u8D44\u6E90\u9884\u7B97\u4E0D\u8DB3");
      const previous = devices.get(String(device));
      if (previous && previous.total !== total)
        return fail5("\u540C\u5361\u8D44\u6E90\u9884\u7B97\u8D85\u51FA\u663E\u5B58");
      devices.set(String(device), {
        total,
        budget: (previous?.budget ?? 0) + gpu2
      });
      budgets.set(model, gpu2);
      ram += memory;
    }
    for (const [device, { total, budget }] of devices) {
      const reserve = reserves[device];
      if (!positive(reserve) || reserve < 2) return fail5("\u9700\u8981\u4FDD\u7559\u663E\u5B58\u4F59\u91CF");
      if (reserve + budget > total) return fail5("\u540C\u5361\u8D44\u6E90\u9884\u7B97\u8D85\u51FA\u663E\u5B58");
    }
    const shared = devices.size === 1;
    if (reserveRam < (shared ? 32 : 16) || totalRam < ram + reserveRam)
      return fail5("\u5E76\u53D1\u7CFB\u7EDF\u5185\u5B58\u4E0D\u8DB3");
    if (shared && (budgets.get(video) < 128 || budgets.get(audio) < 12 || Number(reserves[devices.keys().next().value]) < 16))
      return fail5("\u540C\u5361\u5E76\u53D1\u9884\u7B97\u4E0D\u8DB3");
    return {
      mode: "parallel",
      policy: value.policy,
      lanes,
      ram_total_gib: totalRam,
      reserve_ram_gib: reserveRam,
      reserve_vram_gib: reserves,
      shared_gpu: shared
    };
  }
};

// plugins/gpu/src/node-management.ts
import { hasStudioPackages } from "fumiao:packages/platform/src/studio-plugin-profile.js";
import { timingSafeEqual as timingSafeEqual2 } from "node:crypto";
import { one } from "fumiao:packages/platform/src/db.js";
import { executableJob } from "fumiao:packages/platform/src/retired-jobs.js";
import { Executor } from "fumiao:packages/platform/src/executor.js";
import { GpuGateway } from "fumiao:packages/platform/src/gpu.js";
import { hash, requireValue } from "fumiao:packages/platform/src/security.js";
import { JobTiming } from "fumiao:packages/platform/src/timing.js";
var numbered = /^弗淼([0-9]{1,9})$(?![\s\S])/u;
var defaultName = (n) => "\u5F17\u6DFC" + String(n).padStart(3, "0");
var controls = /* @__PURE__ */ new Map([
  ["drain", "draining"],
  ["resume", "active"],
  ["stop", "paused"],
  ["remove", "removed"]
]);
function shellQuote(value) {
  return /^[\w@%+=:,./-]+$/.test(value) ? value : "'" + value.replaceAll("'", `'"'"'`) + "'";
}
async function nextNumber(sql) {
  const row = await one(
    sql,
    `SELECT GREATEST(node_name_sequence, (
      SELECT max(substring(label FROM 3)::bigint) FROM (
        SELECT label FROM gpu_pairings UNION ALL SELECT name FROM gpu_nodes
        UNION ALL SELECT label FROM original_node_names
      ) names WHERE label ~ '^\u5F17\u6DFC[0-9]{1,9}$'
    )) + 1 AS number FROM original_state_settings`
  );
  return Number(row.number);
}
var BoundNodeCredential = class extends Error {
  name = "BoundNodeCredential";
};
var OriginalNodes = class {
  constructor(p) {
    this.p = p;
    this.gpu = new GpuGateway(p);
  }
  p;
  gpu;
  async suggestedName() {
    return { name: defaultName(await nextNumber(this.p.db)) };
  }
  async pair(actor, input) {
    this.p.admin(actor);
    return this.p.db.transaction(async (sql) => {
      const candidates = (await sql.query(
        `SELECT v.id,v.version FROM plugin_versions v
          WHERE v.manifest->>'mode'='pull' AND v.manifest->'originalState'->'fields' ? 'gpu_models'
          AND EXISTS (SELECT 1 FROM studio_catalog s WHERE s.plugin_id=v.id AND s.plugin_version=v.version)`
      )).rows;
      requireValue(candidates.length === 1, 503, "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528");
      const version = candidates[0];
      if ((await one(sql, "SELECT to_regclass('studio_packages') AS name")).name) {
        const installation = await one(
          sql,
          "SELECT installed,removing FROM studio_packages WHERE id=$1 FOR SHARE",
          [version.id]
        );
        requireValue(
          !installation || installation.installed && !installation.removing,
          409,
          "\u8282\u70B9\u63D2\u4EF6\u6B63\u5728\u79FB\u9664"
        );
      }
      requireValue(
        await this.p.registry.pairedAgent(sql, version.id, version.version),
        503,
        "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528"
      );
      const plugin = await this.p.registry.resolve(
        sql,
        version.id,
        version.version
      );
      requireValue(plugin.originalState, 503, "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528");
      const advertised = plugin.originalState.configuration({
        stamp: Date.now() / 1e3,
        catalog: {},
        imageEnabled: true
      }).gpu_models;
      const models3 = [...new Set(input.models)];
      const slugs = models3.map((id) => {
        requireValue(
          plugin.manifest.models.some((model) => model.id === id),
          400,
          "\u8BF7\u9009\u62E9\u81F3\u5C11\u4E00\u4E2A\u652F\u6301\u7684\u6A21\u578B"
        );
        const slug = advertised?.[id]?.slug;
        requireValue(
          typeof slug === "string" && /^[a-z0-9-]+$(?![\s\S])/.test(slug),
          503,
          "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528"
        );
        return slug;
      });
      requireValue(models3.length > 0, 400, "\u8BF7\u9009\u62E9\u81F3\u5C11\u4E00\u4E2A\u652F\u6301\u7684\u6A21\u578B");
      const connections = (await sql.query(
        `SELECT id FROM connections WHERE plugin_id=$1 AND plugin_version=$2 ${await hasStudioPackages(sql) ? "AND NOT removed" : ""} AND NOT fmworker_resource_driver FOR SHARE`,
        [version.id, version.version]
      )).rows;
      requireValue(connections.length === 1, 503, "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528");
      const owner = await one(
        sql,
        "SELECT id FROM users WHERE id=$1 AND active AND deleted_at IS NULL FOR SHARE",
        [actor.id]
      );
      requireValue(owner, 401, "\u8BF7\u5148\u767B\u5F55");
      await sql.query(
        "SELECT node_name_sequence FROM original_state_settings FOR UPDATE"
      );
      const number = await nextNumber(sql);
      const name = input.name.replace(
        /^[\p{White_Space}\x1c-\x1f]+|[\p{White_Space}\x1c-\x1f]+$/gu,
        ""
      ) || defaultName(number);
      const explicit = numbered.exec(name);
      if (explicit) {
        const taken = await one(
          sql,
          "SELECT label FROM gpu_pairings WHERE label=$1 UNION ALL SELECT name FROM gpu_nodes WHERE name=$1 UNION ALL SELECT label FROM original_node_names WHERE label=$1 LIMIT 1",
          [name]
        );
        requireValue(!taken, 409, "\u5B9E\u4F8B\u540D\u79F0\u5DF2\u4F7F\u7528\uFF0C\u8BF7\u66F4\u6362\u540D\u79F0");
        await sql.query(
          "UPDATE original_state_settings SET node_name_sequence=$1",
          [Math.max(number - 1, Number(explicit[1]))]
        );
      }
      const { code, expires } = await this.gpu.createPairing(
        sql,
        owner.id,
        connections[0].id,
        {
          label: name,
          models: models3
        }
      );
      const site = (process.env.PUBLIC_URL || "http://localhost:3000").replace(
        /\/+$/,
        ""
      );
      return {
        command: `curl -fsSL ${shellQuote(site + "/connect/install.sh")} -o /tmp/fumiao-install.sh && FUMIAO_SITE=${shellQuote(site)} bash /tmp/fumiao-install.sh --models=${slugs.join(",")} ${code}`,
        expires,
        name,
        models: models3
      };
    });
  }
  async enroll(input) {
    const digest = hash(input.code);
    const nodeDigest = hash(input.secret);
    return this.p.db.transaction(async (sql) => {
      const owner = await one(
        sql,
        `SELECT u.id FROM gpu_pairings p JOIN users u ON u.id=p.owner_id
          JOIN connections c ON c.id=p.connection_id
          WHERE NOT c.fmworker_resource_driver AND p.token=$1 AND p.label IS NOT NULL AND u.active AND u.deleted_at IS NULL
          FOR SHARE OF u`,
        [digest]
      );
      requireValue(owner, 403, "\u914D\u5BF9\u7801\u5DF2\u8FC7\u671F\u6216\u65E0\u6548");
      const pair = await one(
        sql,
        "SELECT * FROM gpu_pairings WHERE token=$1 FOR UPDATE",
        [digest]
      );
      requireValue(pair, 403, "\u914D\u5BF9\u7801\u5DF2\u8FC7\u671F\u6216\u65E0\u6548");
      if (pair.claimed) {
        const node = await one(
          sql,
          `SELECT token_hash,enabled FROM gpu_nodes n WHERE id=$1 AND NOT n.archived
            AND NOT EXISTS (SELECT 1 FROM fmworker_resources r WHERE r.node_id=n.id) FOR SHARE OF n`,
          [pair.claimed_node_id]
        );
        requireValue(
          node && timingSafeEqual2(
            Buffer.from(node.token_hash, "hex"),
            Buffer.from(nodeDigest, "hex")
          ),
          403,
          "\u914D\u5BF9\u7801\u5DF2\u4F7F\u7528"
        );
        requireValue(node.enabled, 403, "\u5B9E\u4F8B\u63A5\u5165\u5DF2\u64A4\u9500\uFF0C\u8BF7\u83B7\u53D6\u65B0\u7684\u63A5\u5165\u547D\u4EE4");
      } else {
        await sql.query(
          "SELECT pg_advisory_xact_lock(hashtextextended($1,0))",
          ["gpu-node:" + nodeDigest]
        );
        const stamp2 = await one(sql, "SELECT clock_timestamp() AS now");
        requireValue(pair.expires_at > stamp2.now, 403, "\u914D\u5BF9\u7801\u5DF2\u8FC7\u671F\u6216\u65E0\u6548");
        if (await one(sql, "SELECT 1 FROM gpu_nodes WHERE token_hash=$1", [
          nodeDigest
        ]))
          throw new BoundNodeCredential();
        const node = await this.gpu.addNode(
          sql,
          pair.connection_id,
          pair.owner_id,
          pair.label,
          pair.models,
          nodeDigest
        );
        await sql.query(
          "UPDATE gpu_pairings SET claimed=true,claimed_node_id=$2 WHERE token=$1",
          [digest, node]
        );
      }
      return { ok: true, models: pair.models };
    });
  }
  async registration(authorization) {
    requireValue(authorization.startsWith("Bearer "), 401, "\u7F3A\u5C11\u5B9E\u4F8B\u51ED\u636E");
    const node = await one(
      this.p.db,
      `SELECT n.public_id,n.models,n.control,p.token AS paired_code_hash
        FROM gpu_nodes n JOIN gpu_pairings p ON p.claimed_node_id=n.id
        JOIN connections c ON c.id=n.connection_id
        WHERE n.token_hash=$1 AND n.enabled AND NOT n.archived AND n.control!='removed'
          AND NOT c.fmworker_resource_driver
          AND NOT EXISTS (SELECT 1 FROM fmworker_resources r WHERE r.node_id=n.id)`,
      [hash(authorization.slice(7))]
    );
    requireValue(node, 403, "\u5B9E\u4F8B\u51ED\u636E\u5DF2\u64A4\u9500");
    return {
      id: Number(node.public_id),
      models: node.models,
      paired_code_hash: node.paired_code_hash,
      control: node.control
    };
  }
  async manage(actor, id, action) {
    this.p.admin(actor);
    const control = controls.get(action);
    requireValue(control, 400, "\u672A\u77E5\u64CD\u4F5C");
    return this.p.db.transaction(async (sql) => {
      const node = await one(
        sql,
        `UPDATE gpu_nodes n SET control=$2,enabled=n.enabled AND $2!='removed'
          FROM connections c WHERE c.id=n.connection_id AND NOT c.fmworker_resource_driver
          AND public_id=$1 AND control!='removed'
          AND NOT EXISTS (SELECT 1 FROM fmworker_resources r WHERE r.node_id=n.id) RETURNING n.id`,
        [id, control]
      );
      requireValue(node, 404, "\u5B9E\u4F8B\u4E0D\u5B58\u5728");
      if (action === "stop" || action === "remove")
        await this.interrupt(sql, [node.id], "\u7BA1\u7406\u5458\u5DF2\u65AD\u5F00\u5B9E\u4F8B");
      await new Executor(this.p).recoverOn(sql, true);
      if (action === "drain")
        await sql.query(
          `UPDATE gpu_nodes SET control='paused' WHERE id=$1 AND control='draining'
            AND NOT EXISTS (SELECT 1 FROM jobs j WHERE remote_id=gpu_nodes.id::text AND state IN ('dispatching','running','finalizing','uncertain') AND ${executableJob})`,
          [node.id]
        );
      return { ok: true };
    });
  }
  async removeOwned(sql, owner) {
    await sql.query(
      "UPDATE gpu_pairings SET expires_at=to_timestamp(0) WHERE owner_id=$1",
      [owner]
    );
    const { rows } = await sql.query(
      `SELECT n.id FROM gpu_nodes n JOIN connections c ON c.id=n.connection_id
      WHERE n.owner_id=$1 AND NOT c.fmworker_resource_driver
      AND NOT EXISTS (SELECT 1 FROM fmworker_resources r WHERE r.node_id=n.id) ORDER BY n.id FOR UPDATE OF n`,
      [owner]
    );
    if (!rows.length) return;
    const ids = rows.map(({ id }) => id);
    await this.interrupt(sql, ids, "\u63A5\u5165\u6210\u5458\u5DF2\u79FB\u9664\uFF0C\u7B49\u5F85\u5176\u4ED6\u5B9E\u4F8B");
    await sql.query(
      `UPDATE gpu_nodes SET control='removed',enabled=false,
        queue_state=jsonb_set(queue_state,'{stage}','"offline"')
        WHERE id=ANY($1::uuid[])`,
      [ids]
    );
  }
  async interrupt(sql, nodes, note) {
    const { rows: jobs } = await sql.query(
      `SELECT j.* FROM jobs j WHERE remote_id=ANY($1::text[]) AND state='running'
       AND ${executableJob} ORDER BY workspace_id,id FOR UPDATE OF j`,
      [nodes]
    );
    const timing = new JobTiming(this.p);
    const stamp2 = Math.floor(Date.now() / 1e3);
    for (const job of jobs) {
      requireValue(job.attempts !== null, 503, "\u4EFB\u52A1\u6267\u884C\u6B21\u6570\u5C1A\u672A\u5B8C\u6210\u8FC1\u79FB");
      await timing.end(sql, job, "interrupted", stamp2);
      if (job.attempts >= 2)
        await this.p.settle(sql, job, "failed", void 0, note, void 0, {
          preserveTiming: true
        });
      await sql.query(
        `UPDATE jobs SET state=CASE WHEN state='running' THEN 'queued' ELSE state END,
          remote_id=NULL,original_node=NULL,original_gpu_ticket=NULL,lease_token=NULL,
          lease_until=NULL,request_note=NULL,error=$2,updated_at=now()
          WHERE id=$1`,
        [job.id, note]
      );
    }
  }
};

// plugins/gpu/src/agent-dispatch.ts
import { queuedModelPolicy } from "fumiao:packages/platform/src/studio-plugin-profile.js";
import { loadProgram } from "fumiao:packages/platform/src/plugin-program.js";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { isDeepStrictEqual } from "node:util";
import {
  PairedAgentPlanError as PairedAgentPlanError2
} from "fumiao:packages/plugin-sdk/src/paired-agent.js";
import { one as one2 } from "fumiao:packages/platform/src/db.js";
import { Executor as Executor2 } from "fumiao:packages/platform/src/executor.js";
import { GpuGateway as GpuGateway2 } from "fumiao:packages/platform/src/gpu.js";
import {
  DomainError,
  hash as hash2,
  requireValue as requireValue2,
  secret
} from "fumiao:packages/platform/src/security.js";
import { executableJob as executableJob2 } from "fumiao:packages/platform/src/retired-jobs.js";
import { JobTiming as JobTiming2 } from "fumiao:packages/platform/src/timing.js";
var stamp = () => Math.floor(Date.now() / 1e3);
var inactive = "\u8BE5\u4EFB\u52A1\u5DF2\u7531\u5176\u4ED6\u5B9E\u4F8B\u63A5\u7BA1\u6216\u5DF2\u7ED3\u675F";
var protocolOnly = { job: null, protocol: 2 };
var leaseDeadline = "date_trunc('second',clock_timestamp())+interval '180 seconds'";
function queueNode(node) {
  return {
    ...node.timing_context,
    ...node.queue_state,
    id: node.id,
    control: node.control,
    lastseen: Math.floor(node.last_seen.getTime() / 1e3),
    stage: node.queue_state.stage ?? "preparing",
    ready_models: node.queue_state.ready_models ?? []
  };
}
function queueJob(job) {
  return {
    id: job.id,
    node: job.remote_id,
    kind: job.kind,
    status: job.state,
    model: job.provider_model,
    input: {
      ...job.input,
      references: job.input.references.map((id) => ({
        id,
        width: 0,
        height: 0
      }))
    }
  };
}
var OriginalPairedAgent = class {
  constructor(p) {
    this.p = p;
    this.timing = new JobTiming2(p);
  }
  p;
  timing;
  async node(sql, credential, lock = false) {
    const auth = credential.authorization;
    requireValue2(auth.startsWith("Bearer "), 401, "\u7F3A\u5C11\u5B9E\u4F8B\u51ED\u636E");
    const node = await one2(
      sql,
      `SELECT n.*,c.plugin_id,c.plugin_version FROM gpu_nodes n JOIN connections c ON c.id=n.connection_id
       WHERE n.token_hash=$1 AND n.enabled AND NOT n.archived AND n.control!='removed' AND NOT c.fmworker_resource_driver
       AND EXISTS (SELECT 1 FROM gpu_pairings p WHERE p.claimed_node_id=n.id)
       AND NOT EXISTS (SELECT 1 FROM fmworker_resources r WHERE r.node_id=n.id)${lock ? " FOR UPDATE OF n" : ""}`,
      [hash2(auth.slice(7))]
    );
    requireValue2(node, 403, "\u5B9E\u4F8B\u51ED\u636E\u5DF2\u64A4\u9500");
    return node;
  }
  async protocol(sql, node) {
    const protocol = await this.p.registry.pairedAgent(
      sql,
      node.plugin_id,
      node.plugin_version
    );
    requireValue2(protocol, 503, "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528");
    return protocol;
  }
  async running(sql, node, lane = "", lock = false) {
    return (await sql.query(
      `SELECT j.* FROM jobs j WHERE remote_id=$1 AND state='running' AND original_gpu_ticket IS NOT NULL AND ($2='' OR provider_model=$2) AND ${executableJob2} ORDER BY public_id` + (lock ? " FOR UPDATE" : ""),
      [node.id, lane]
    )).rows;
  }
  summarize(node, protocol, running, now) {
    const rows = node.queue_state.lanes ?? [];
    const alive = rows.filter((lane) => lane.lastseen > now - 75);
    if (!alive.length && !running.length) return;
    const ready = alive.filter(
      (lane) => ["ready", "busy"].includes(lane.stage)
    );
    const errors = alive.filter((lane) => lane.stage === "error");
    const blocked = alive.filter(
      (lane) => lane.stage === "ready" && !lane.can_accept
    );
    const notices = errors.length ? errors : blocked;
    node.queue_state.stage = running.length ? "busy" : ready.length ? "ready" : errors.length ? "error" : "preparing";
    node.queue_state.ready_models = ready.map((lane) => lane.model);
    node.detail = notices.length ? [
      ...notices.map(
        (lane) => protocol.models[lane.model].label + "\uFF1A" + lane.detail
      ).join("\uFF1B")
    ].slice(0, 300).join("") : running.length > 1 ? "\u89C6\u9891\u4E0E\u8BED\u97F3\u751F\u6210\u4E2D" : running.length ? running[0].kind === "audio" ? "\u6B63\u5728\u751F\u6210\u8BED\u97F3" : "\u6B63\u5728\u751F\u6210\u89C6\u9891" : ready.length ? "\u5C31\u7EEA" : "\u6B63\u5728\u51C6\u5907\u6A21\u578B";
  }
  async heartbeat(credential, beat) {
    requireValue2(
      ["preparing", "ready", "busy", "error"].includes(beat.stage),
      400,
      "\u72B6\u6001\u65E0\u6548"
    );
    return this.p.db.transaction(async (sql) => {
      const node = await this.node(sql, credential, true);
      const protocol = await this.protocol(sql, node), state = node.queue_state, context = node.timing_context;
      const lane = beat.lane_model, model = protocol.legacyModel, now = stamp();
      if (beat.video_steps) {
        requireValue2(node.models.includes(model), 400, "\u5B9E\u4F8B\u6CA1\u6709\u63A5\u5165\u89C6\u9891\u6A21\u578B");
        requireValue2(!lane || lane === model, 400, "\u901A\u9053\u4E0D\u80FD\u4FEE\u6539\u89C6\u9891\u80FD\u529B");
        state.video_steps = [...new Set(beat.video_steps)].sort(
          (a, b) => a - b
        );
      } else if (!lane && node.models.includes(model)) state.video_steps = [20];
      if (!lane && beat.runtime_id && beat.runtime_id !== context.runtime_id)
        state.lanes = [];
      if (beat.execution_plan) {
        let plan2;
        try {
          plan2 = protocol.plan(beat.execution_plan, node.models);
        } catch (error) {
          if (error instanceof PairedAgentPlanError2)
            throw new DomainError(400, error.message);
          throw error;
        }
        const prior = state.execution_plan;
        if (!isDeepStrictEqual(plan2, prior)) {
          requireValue2(
            plan2.mode === "serial" && prior?.mode !== "parallel" || !(await this.running(sql, node)).length,
            409,
            "\u8BF7\u5148\u7B49\u5F85\u5B9E\u4F8B\u4EFB\u52A1\u5B8C\u6210\u540E\u66F4\u6539\u6267\u884C\u65B9\u5F0F"
          );
          state.execution_plan = plan2;
          state.lanes = [];
        }
      }
      const plan = state.execution_plan;
      requireValue2(
        !lane || plan?.mode === "parallel" && Object.hasOwn(plan.lanes, lane),
        400,
        "\u5B9E\u4F8B\u6CA1\u6709\u8FD9\u4E2A\u5E76\u53D1\u6267\u884C\u901A\u9053"
      );
      if (beat.ready_models) {
        requireValue2(
          beat.ready_models.every((id) => node.models.includes(id)),
          400,
          "\u5B9E\u4F8B\u6CA1\u6709\u63A5\u5165\u8FD9\u4E9B\u6A21\u578B"
        );
        if (!lane) state.ready_models = [...new Set(beat.ready_models)];
      } else if (!lane && beat.stage === "ready" && node.models.length === 1 && node.models[0] === model)
        state.ready_models = [model];
      if (beat.model_profiles) {
        const models3 = Object.keys(beat.model_profiles);
        requireValue2(
          models3.every((id) => node.models.includes(id)),
          400,
          "\u6A21\u578B\u8FD0\u884C\u73AF\u5883\u4E0E\u63A5\u5165\u914D\u7F6E\u4E0D\u7B26"
        );
        requireValue2(
          !lane || models3.length === 1 && models3[0] === lane,
          400,
          "\u5E76\u53D1\u901A\u9053\u53EA\u80FD\u4E0A\u62A5\u81EA\u5DF1\u7684\u6A21\u578B\u73AF\u5883"
        );
        context.model_profiles = {
          ...lane ? context.model_profiles : {},
          ...beat.model_profiles
        };
      }
      state.stage = beat.stage;
      node.detail = beat.detail;
      if (!lane) {
        if (beat.hardware) context.hardware = beat.hardware;
        if (beat.workflow) context.workflow = beat.workflow;
        if (beat.runtime_id) context.runtime_id = beat.runtime_id;
        if (beat.profile) {
          context.profile = beat.profile;
          context.hardware = protocol.hardware(beat.profile);
        }
      }
      const held = beat.ticket ? await this.renew(sql, node, beat, now) : false;
      if (lane) {
        const lanes = new Map(
          (state.lanes ?? []).map((item) => [item.model, item])
        );
        const value = {
          model: lane,
          lastseen: now,
          stage: !beat.ready_models || beat.ready_models.includes(lane) ? beat.stage : "preparing",
          detail: beat.detail,
          runtime_id: beat.runtime_id,
          can_accept: beat.can_accept,
          profile: beat.profile ?? {}
        };
        lanes.set(lane, value);
        state.lanes = [...lanes.values()];
      }
      if (plan?.mode === "parallel")
        this.summarize(node, protocol, await this.running(sql, node), now);
      await sql.query(
        "UPDATE gpu_nodes SET last_seen=to_timestamp($2),timing_context=$3,queue_state=$4,detail=$5 WHERE id=$1",
        [
          node.id,
          now,
          JSON.stringify(context),
          JSON.stringify(state),
          node.detail
        ]
      );
      return {
        control: node.control,
        held,
        protocol: protocol.version,
        execution_mode: plan?.mode ?? "serial"
      };
    });
  }
  async renew(sql, node, beat, now) {
    const job = await one2(
      sql,
      `SELECT j.* FROM jobs j WHERE remote_id=$1 AND original_gpu_ticket=$2 AND state IN ('running','queued') AND ${executableJob2} FOR UPDATE OF j`,
      [node.id, beat.ticket]
    );
    if (!job || beat.lane_model && beat.lane_model !== job.provider_model)
      return false;
    if (job.state === "queued" && (node.control !== "active" || (await this.running(
      sql,
      node,
      node.queue_state.execution_plan?.mode === "parallel" ? job.provider_model : ""
    )).length))
      return false;
    const { step, steps, uploading, job_phase, timing } = beat;
    const note = uploading ? "\u6B63\u5728\u56DE\u4F20\u5E76\u6821\u9A8C\u6210\u7247" : step != null && steps != null && step <= steps ? `\u91C7\u6837 ${step} / ${steps} \u6B65` : null;
    await sql.query(
      `UPDATE jobs SET state='running',lease_token=COALESCE(lease_token,$2),lease_until=${leaseDeadline},error=$3 WHERE id=$1`,
      [job.id, randomUUID(), note]
    );
    const report = {
      step: step ?? void 0,
      steps: steps ?? void 0,
      uploading: uploading ?? void 0,
      job_phase: job_phase ?? void 0,
      timing: timing ?? void 0
    };
    await this.timing.observe(sql, job.id, report, now);
    return true;
  }
  async eligible(sql, protocol, node, job) {
    if (!job.package_version) return protocol.canRun(node, queueJob(job));
    const release = await one2(
      sql,
      "SELECT package->>'program' AS program FROM studio_package_releases WHERE id=$1 AND version=$2",
      [job.plugin_id, job.package_version]
    );
    if (!release?.program) return protocol.canRun(node, queueJob(job));
    const run = await loadProgram(release.program);
    return run("eligible", node, queueJob(job)) === true;
  }
  async claim(credential) {
    await this.node(this.p.db, credential);
    await this.p.db.transaction(
      (sql) => new Executor2(this.p).recoverOn(sql, true)
    );
    return this.p.db.transaction(async (sql) => {
      const node = await this.node(sql, credential, true);
      const protocol = await this.protocol(sql, node), lane = credential.lane, state = node.queue_state;
      const plan = state.execution_plan;
      const parallel = plan?.mode === "parallel", now = stamp();
      if (parallel && !lane) return protocolOnly;
      if (parallel)
        requireValue2(Object.hasOwn(plan.lanes, lane), 400, "\u6267\u884C\u901A\u9053\u672A\u6388\u6743");
      else requireValue2(!lane, 409, "\u670D\u52A1\u5668\u5F53\u524D\u53EA\u5141\u8BB8\u5355\u901A\u9053\u6267\u884C");
      const current = (await this.running(sql, node, lane, true))[0];
      const view = queueNode(node);
      if (current)
        return {
          job: await this.eligible(sql, protocol, view, current) ? await this.payload(sql, current) : null,
          protocol: protocol.version
        };
      const slot = state.lanes?.find((item) => item.model === lane);
      const fresh = parallel ? slot?.stage === "ready" && slot.lastseen >= now - 75 && slot.can_accept : view.stage === "ready" && view.lastseen >= now - 75;
      const installed = (view.ready_models ?? []).filter(
        (id) => node.models.includes(id) && (!lane || id === lane)
      );
      const pauseFile = process.env.ORIGINAL_GPU_DISPATCH_PAUSE_FILE;
      if (!fresh || !installed.length || node.control !== "active" || pauseFile && existsSync(pauseFile))
        return protocolOnly;
      const job = await this.next(sql, node, installed, view, protocol);
      if (!job) return { job: null };
      requireValue2(job.attempts !== null, 503, "\u4EFB\u52A1\u6267\u884C\u6B21\u6570\u5C1A\u672A\u5B8C\u6210\u8FC1\u79FB");
      const lease = randomUUID();
      job.original_gpu_ticket = secret();
      job.attempts += 1;
      await sql.query(
        `UPDATE jobs SET state='running',lease_token=$2,lease_until=${leaseDeadline},remote_id=$3,
          original_gpu_ticket=$4,attempts=$5,error=NULL,updated_at=now() WHERE id=$1`,
        [job.id, lease, node.id, job.original_gpu_ticket, job.attempts]
      );
      await this.timing.start(sql, { ...job, lease_token: lease }, true, {
        ...node.timing_context,
        id: node.id,
        ...lane ? { lane_model: lane } : {}
      });
      if (slot) {
        slot.stage = "busy";
        this.summarize(node, protocol, await this.running(sql, node), now);
        await sql.query(
          "UPDATE gpu_nodes SET queue_state=$2,detail=$3 WHERE id=$1",
          [node.id, JSON.stringify(state), node.detail]
        );
      }
      return { job: await this.payload(sql, job) };
    });
  }
  async next(sql, node, models3, view, protocol) {
    const candidates = `SELECT j.* FROM jobs j JOIN connections c ON c.id=j.connection_id
      JOIN models m ON m.id=j.model_id
      JOIN plugin_versions v ON v.id=j.plugin_id AND v.version=j.plugin_version
      LEFT JOIN model_permissions mp ON mp.model_id=m.id AND mp.workspace_id=j.workspace_id
      WHERE j.connection_id=$1 AND c.enabled AND j.state='queued' AND j.original_uid IS NOT NULL AND j.deleted_at IS NULL
      AND v.manifest->>'mode'='pull' AND NOT (v.manifest ? 'fmworkerResources') AND v.manifest->'artifactValidation' IS NOT NULL AND v.manifest->'originalState'->'recovery' IS NOT NULL
      AND j.provider_model=ANY($2::text[]) AND ${await queuedModelPolicy(sql)} AND COALESCE(mp.enabled,true) AND ${executableJob2}`;
    let cursor = 0;
    for (; ; ) {
      const rows = (await sql.query(
        candidates + " AND j.public_id>$3 ORDER BY j.public_id LIMIT 100",
        [node.connection_id, models3, cursor]
      )).rows;
      if (!rows.length) return void 0;
      for (const job of rows) {
        cursor = Number(job.public_id);
        if (!await this.eligible(sql, protocol, view, job)) continue;
        const locked = await one2(
          sql,
          candidates + " AND j.id=$3 FOR UPDATE OF j SKIP LOCKED",
          [node.connection_id, models3, job.id]
        );
        if (locked) return locked;
      }
    }
  }
  async payload(sql, job) {
    const refs = (await sql.query(
      "SELECT a.public_id FROM unnest($1::uuid[]) WITH ORDINALITY AS r(id,i) JOIN assets a ON a.id=r.id AND a.workspace_id=$2 ORDER BY r.i",
      [job.input.references, job.workspace_id]
    )).rows.map((row) => row.public_id);
    requireValue2(
      refs.length === job.input.references.length,
      503,
      "\u4EFB\u52A1\u7D20\u6750\u5C1A\u672A\u5B8C\u6574\u8FC1\u79FB"
    );
    const {
      seed,
      width,
      height,
      seconds,
      sampling_steps,
      quality,
      audio_settings,
      h3_inputs
    } = job.original_view;
    return {
      id: Number(job.public_id),
      ticket: job.original_gpu_ticket,
      prompt: job.input.prompt,
      seed,
      width,
      height,
      seconds,
      sampling_steps,
      quality,
      attempts: job.attempts,
      refs,
      model: job.provider_model,
      kind: job.kind,
      audio_settings,
      h3_inputs
    };
  }
  async assignment(sql, credential, id, completed = false) {
    const node = await this.node(sql, credential, true);
    const job = await one2(
      sql,
      `SELECT j.* FROM jobs j WHERE public_id=$1 AND remote_id=$2 AND original_gpu_ticket=$3 AND deleted_at IS NULL AND ${executableJob2} FOR UPDATE OF j`,
      [id, node.id, credential.ticket]
    );
    requireValue2(
      !job || !credential.lane || credential.lane === job.provider_model,
      409,
      "\u4EFB\u52A1\u4E0D\u5C5E\u4E8E\u8FD9\u4E2A\u6267\u884C\u901A\u9053"
    );
    requireValue2(
      job?.state === "running" || completed && job?.state === "completed",
      409,
      inactive
    );
    return job;
  }
  async receipt(credential, id) {
    return this.p.db.transaction(async (sql) => ({
      delivered: (await this.assignment(sql, credential, id, true)).state === "completed"
    }));
  }
  async reference(credential, id, key) {
    return this.p.db.transaction(async (sql) => {
      const job = await this.assignment(sql, credential, id);
      const asset = await one2(
        sql,
        "SELECT * FROM assets WHERE public_id=$1 AND workspace_id=$2 AND id=ANY($3::uuid[]) AND state='ready'",
        [key, job.workspace_id, job.input.references]
      );
      requireValue2(asset, 403, "\u7D20\u6750\u4E0D\u5C5E\u4E8E\u672C\u4EFB\u52A1");
      return asset;
    });
  }
  async error(credential, id, detail) {
    return this.p.db.transaction(async (sql) => {
      const job = await this.assignment(sql, credential, id);
      await this.p.settle(
        sql,
        job,
        "failed",
        void 0,
        [...detail].slice(0, 220).join("") || "\u751F\u6210\u5931\u8D25"
      );
      return { ok: true };
    });
  }
  async complete(credential, id, load, receipt) {
    const result = await new GpuGateway2(this.p).deliver(
      void 0,
      (sql) => this.assignment(sql, credential, id, true),
      load,
      receipt,
      {
        params: (job) => ({
          ...job.input.params,
          h3_inputs: job.original_view.h3_inputs
        }),
        preflight: async (provider, job, headers, sql, version) => {
          const protocol = await this.p.registry.pairedAgent(
            sql,
            provider,
            version
          );
          requireValue2(protocol, 503, "GPU \u63A5\u5165\u6682\u4E0D\u53EF\u7528");
          protocol.preflight(job, headers);
        },
        settled: async (sql, job) => {
          await sql.query(
            `UPDATE gpu_nodes n SET control='paused' WHERE n.control='draining'
              AND n.id=$1
              AND NOT EXISTS (SELECT 1 FROM jobs WHERE remote_id=n.id::text AND state='running')`,
            [job.remote_id]
          );
        }
      }
    );
    const asset = await one2(
      this.p.db,
      "SELECT public_id FROM assets WHERE id=$1",
      [result.assets[0]]
    );
    requireValue2(asset, 503, "\u6210\u7247\u5C1A\u672A\u5B8C\u6574\u8FC1\u79FB");
    return { ok: true, id: asset.public_id };
  }
};
export {
  OriginalPairedAgent as Agent,
  OriginalNodes as NodeManagement,
  gpuText as adapter,
  gpuPairedAgent as protocol
};
